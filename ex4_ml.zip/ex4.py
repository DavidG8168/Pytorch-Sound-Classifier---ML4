# ========================================= IMPORTS ===================================================================
import os
import os.path
import soundfile as sf
import librosa
import numpy as np
import tqdm
import torch
import torch.utils.data as data
import torch.utils.data
import torch.cuda
import torch.nn.functional as functional
import torch.cuda
from torch import nn, optim
from torch.autograd import Variable

# ========================================= VARIABLES =================================================================
# Variables used in the program.
epochs = 50
validation_batch = 5000
max_len = 101
training_batch = 400
testing_batch = 200

AUDIO_EXTENSIONS = [
    '.wav', '.WAV']

# Class dictionary.
classes = {'bed': '0\n', 'bird': '1\n', 'cat': '2\n', 'dog': '3\n', 'down': '4\n', 'eight': '5\n', 'five': '6\n',
           'four': '7\n', 'go': '8\n', 'happy': '9\n',
           'house': '10\n', 'left': '11\n', 'marvin': '12\n', 'nine': '13\n', 'no': '14\n', 'off': '15\n', 'on': '16\n',
           'one': '17\n', 'right': '18\n',
           'seven': '19\n', 'sheila': '20\n', 'six': '21\n', 'stop': '22\n', 'three': '23\n', 'tree': '24\n',
           'two': '25\n', 'up': '26\n', 'wow': '27\n',
           'yes': '28\n', 'zero': '29\n'}

# File list/array.
files = []


# ========================================== INSTRUCTOR'S CODE ========================================================
def is_audio_file(filename):
    return any(filename.endswith(extension) for extension in AUDIO_EXTENSIONS)


def find_classes(dir):
    classes = [d for d in os.listdir(dir) if os.path.isdir(os.path.join(dir, d))]
    classes.sort()
    class_to_idx = {classes[i]: i for i in range(len(classes))}
    return classes, class_to_idx


def make_dataset(dir, class_to_idx):
    spects = []
    dir = os.path.expanduser(dir)
    for target in sorted(os.listdir(dir)):
        d = os.path.join(dir, target)
        if not os.path.isdir(d):
            continue

        for root, _, fnames in sorted(os.walk(d)):
            for fname in sorted(fnames):
                if is_audio_file(fname):
                    path = os.path.join(root, fname)
                    item = (path, class_to_idx[target])
                    spects.append(item)
    return spects


def spect_loader(path, window_size, window_stride, window, normalize, max_len=101):
    y, sr = sf.read(path)
    # n_fft = 4096
    n_fft = int(sr * window_size)
    win_length = n_fft
    hop_length = int(sr * window_stride)

    # STFT
    D = librosa.stft(y, n_fft=n_fft, hop_length=hop_length,
                     win_length=win_length, window=window)
    spect, phase = librosa.magphase(D)

    # S = log(S+1)
    spect = np.log1p(spect)

    # make all spects with the same dims
    # TODO: change that in the future
    if spect.shape[1] < max_len:
        pad = np.zeros((spect.shape[0], max_len - spect.shape[1]))
        spect = np.hstack((spect, pad))
    elif spect.shape[1] > max_len:
        spect = spect[:, :max_len]
    spect = np.resize(spect, (1, spect.shape[0], spect.shape[1]))
    spect = torch.FloatTensor(spect)

    # z-score normalization
    if normalize:
        mean = spect.mean()
        std = spect.std()
        if std != 0:
            spect.add_(-mean)
            spect.div_(std)

    return spect


class GCommandLoader(data.Dataset):
    """A google command data set loader where the wavs are arranged in this way: ::
        root/one/xxx.wav
        root/one/xxy.wav
        root/one/xxz.wav
        root/head/123.wav
        root/head/nsdf3.wav
        root/head/asd932_.wav
    Args:
        root (string): Root directory path.
        transform (callable, optional): A function/transform that  takes in an PIL image
            and returns a transformed version. E.g, ``transforms.RandomCrop``
        target_transform (callable, optional): A function/transform that takes in the
            target and transforms it.
        window_size: window size for the stft, default value is .02
        window_stride: window stride for the stft, default value is .01
        window_type: typye of window to extract the stft, default value is 'hamming'
        normalize: boolean, whether or not to normalize the spect to have zero mean and one std
        max_len: the maximum length of frames to use
     Attributes:
        classes (list): List of the class names.
        class_to_idx (dict): Dict with items (class_name, class_index).
        spects (list): List of (spects path, class_index) tuples
        STFT parameter: window_size, window_stride, window_type, normalize
    """

    def __init__(self, root, transform=None, target_transform=None, window_size=.02,
                 window_stride=.01, window_type='hamming', normalize=True, max_len=101):
        classes, class_to_idx = find_classes(root)
        spects = make_dataset(root, class_to_idx)
        if len(spects) == 0:
            raise (RuntimeError("Found 0 sound files in subfolders of: " + root +
                                "Supported audio file extensions are: " + ",".join(AUDIO_EXTENSIONS)))

        self.root = root
        self.spects = spects
        self.classes = classes
        self.class_to_idx = class_to_idx
        self.transform = transform
        self.target_transform = target_transform
        self.loader = spect_loader
        self.window_size = window_size
        self.window_stride = window_stride
        self.window_type = window_type
        self.normalize = normalize
        self.max_len = max_len
        for i in self.spects:
            files.append(i[0])

    def __getitem__(self, index):
        """
        Args:
            index (int): Index
        Returns:
            tuple: (spect, target) where target is class_index of the target class.
        """
        path, target = self.spects[index]
        spect = self.loader(path, self.window_size, self.window_stride, self.window_type, self.normalize, self.max_len)
        if self.transform is not None:
            spect = self.transform(spect)
        if self.target_transform is not None:
            target = self.target_transform(target)

        return spect, target

    def __len__(self):
        return len(self.spects)


# ================================= THE NETWORK =======================================================================
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self._conv1 = nn.Conv2d(in_channels=1, out_channels=20, kernel_size=5, stride=1)
        self._conv2 = nn.Conv2d(in_channels=20, out_channels=50, kernel_size=5, stride=1)
        self._dropout = nn.Dropout(p=0.5)
        size_of_height = 50
        size_of_width = 37
        filter = 22
        size_of_elem = 30
        mul = size_of_height * size_of_width * filter
        self._l1 = nn.Linear(mul, size_of_elem)
        self._loss_function = nn.CrossEntropyLoss()
        self._optimizer = optim.Adam(self.parameters(), lr=1e-4)


    def forward(self, x):
        x = Variable(x)
        if torch.cuda.is_available():
            x = x.cuda()
        x = self._conv1(x)
        x = functional.max_pool2d(x, kernel_size=2, stride=2)
        x = self._conv2(x)
        x = functional.max_pool2d(x, kernel_size=2, stride=2)
        # relu
        x = functional.relu(x)
        # dropout
        x = self._dropout(x)
        x = x.view(x.size(0), -1)
        x = self._l1(x)
        return x

    def train_example(self, vectors, labels):
        labels = Variable(labels)
        vectors = Variable(vectors)

        if torch.cuda.is_available():
            labels = labels.cuda()
            vectors = vectors.cuda()

        self._optimizer.zero_grad()
        loss = self._loss_function(self(vectors), labels)
        loss.backward()
        self._optimizer.step()


# =================================== OTHER FUNCTIONS =================================================================
def accuracy(net, data_set):
    total = 0
    correct = 0
    for vectors, labels in data_set:
        labels = Variable(labels)
        if torch.cuda.is_available():
            labels = labels.cuda()
        outputs = net(vectors)
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
        if total >= validation_batch:
            div = correct / total
            return div


def get_class_keys(dic, value):
    for item in dic.items():
        if item[1] == value:
            return item[0]


# =================================== MAIN ============================================================================
def main():
    # ======================================= GET DATA ================================================================
    net = Net()
    # Loading the data from the files using the instructor's code.
    if torch.cuda.is_available():
        net.cuda()
    train_set = torch.utils.data.DataLoader(GCommandLoader('./data/train'), batch_size=training_batch, shuffle=False,
                                            num_workers=4, pin_memory=True, sampler=None)
    validation_set = torch.utils.data.DataLoader(GCommandLoader('./data/valid'), batch_size=testing_batch, shuffle=False,
                                                 num_workers=4, pin_memory=True, sampler=None)
    test_set = torch.utils.data.DataLoader(GCommandLoader('./data/test'), batch_size=testing_batch, shuffle=False,
                                           num_workers=4, pin_memory=True, sampler=None)
    # Getting the test set file names.
    need_files = files[36798:]
    new_files_edited = []
    for file in need_files:
        new_files_edited.append(file[17:])

    # ======================================= TRAIN ===================================================================
    # Training the algorithm.
    for i in range(epochs):
        net.train()
        for vector_batch, label_batch in tqdm.tqdm(train_set, total=len(train_set), unit_scale=training_batch):
            net.train_example(vector_batch, label_batch)
        net.eval()
        accuracy(net, train_set)
        accuracy(net, validation_set)

    # ======================================= TEST ====================================================================
    net.eval()
    # Create a file and write the predictions to it.
    f = open("test_y", "w")
    for vectors_batch, _ in test_set:
        outputs = net(vectors_batch)
        _, predictions = torch.max(outputs.data, 1)
        for prediction in predictions:
            f.write(str(prediction.item()) + "\n")
    f.close()

    # ======================================= MAP VALUES ==============================================================
    # Re-open the file to write the correct format for it.
    read_file = open("test_y")
    lines = read_file.readlines()
    new_lines = []
    i = 0
    for line in lines:
        # str_class = get_class_keys(classes, line)
        write_me = new_files_edited[i] + ',' + ' ' + line
        new_lines.append(write_me)
        i = i + 1
    # ======================================= DELETE NEWLINE ==========================================================
    # Remove the last blank line from the file.
    new_lines[len(new_lines) - 1] = new_lines[len(new_lines) - 1][:-1]
    read_file.close()
    w = open("test_y", 'w')
    w.writelines([item for item in new_lines])
    w.close()


if __name__ == '__main__':
    main()
